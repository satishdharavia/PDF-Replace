jQuery(function() {
   var id = jQuery('#toplevel_page_theme-general-settings').attr("id");
   if(id == 'toplevel_page_theme-general-settings')
   {
	   jQuery('#toplevel_page_pdf-replace').insertAfter('#toplevel_page_theme-general-settings ul li:last-child');
   }
});



