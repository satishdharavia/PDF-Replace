<?php
/*
Plugin Name: PDF Replace
Plugin URI: http://www.test.com
Description: Enable replacing pdf files by uploading a new file in the "Edit PDF" section of the WordPress Media Library.
Version: 1.0.1
Author: john
Author URI: https://test.com



 *
 */
 /**
 * Register a custom menu page.
 */
 
function wpdocs_register_pr_custom_menu_page(){
    add_menu_page( 
        __( 'PDF Replace', 'textdomain' ),
        'PDF Replace ',
        'manage_options',
        'pdf-replace',
        'pr_custom_menu_page',
        plugins_url( 'pdf-replace/images/icon.png' )
        
    ); 
}
add_action( 'admin_menu', 'wpdocs_register_pr_custom_menu_page' );
 
/**
 * Display a custom menu page
 */
function pr_custom_menu_page(){
	$upload_dir   = wp_upload_dir();
	
	$target_dir   = $upload_dir['basedir']."/pdf-replace/";
	?>
	<div id="poststuff">
	<div class="postbox pdf_replace"> 
	<h2>PDF Replace</h2>
	<form action="" method="post" enctype="multipart/form-data" id="pdf-replace" class="inside">
		<p>
			<div class="acf-label"><label for="fileToUpload"><b>Select image to upload:</b></label></div>
			<input type="file" name="fileToUpload" id="fileToUpload">
		</p>
		<?php $file_name = get_option( 'pr_file_name'); ?>
		<div <?php if($file_name != ''){ echo 'style="display:none;"';}?>> 
		<p >
		
		<div class="acf-label"><label for="file_name"><b>File Name:</b></label></div>
		<input required placeholder="test.pdf" type="text" name="file_name" id="file_name" value="<?php echo $file_name;?>" <?php if($file_name != ''){echo 'readonly';}?>>
		</p>
		</div>
		<div <?php if($file_name == ''){ echo 'style="display:none;"';}?>>
		<p>
			<div class="acf-label"><label for="file_url"><b>File URL:</b></label></div>
		<input onclick="this.select()". type="text" name="file_url" id="file_url" value="<?php echo $upload_dir['baseurl'].'/pdf-replace/'.$file_name;?>" readonly>
		</p>
		</div>
		<p>
		<input type="submit" value="Upload PDF" name="submit" class="button button-primary button-large">
		</p>
	</form>
	</div>
	</div>
	<?php 
	
	
	// Check if image file is a actual image or fake image
	if(isset($_POST["submit"])) {
		$target_file = $target_dir . basename($_POST['file_name']);
		$uploadOk = 1;
		$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		if($_POST['file_name'])
		{
			update_option( 'pr_file_name',  $_POST['file_name']);
		}
		$check = @getimagesize($_FILES["fileToUpload"]["tmp_name"]);
		if($check !== false) {
			echo "File is an image - " . $check["mime"] . ".";
			$uploadOk = 1;
		} 
		
		if($_FILES["fileToUpload"]["tmp_name"] == '')
		{
			echo "Please select PDF file.";
			$uploadOk = 0;
		}
	}
	// Check if file already exists
	/*if (file_exists($target_file)) {
		echo "Sorry, file already exists.";
		$uploadOk = 0;
	}*/
	// Check file size
	if ($_FILES["fileToUpload"]["size"] > 500000) {
		echo "Sorry, your file is too large.";
		$uploadOk = 0;
	}
	// Allow certain file formats
	/*if($imageFileType != "PDF" && $imageFileType != "pdf" ) {
		echo "Sorry, only PDF files are allowed.";
		$uploadOk = 0;
	}*/
	// Check if $uploadOk is set to 0 by an error
	if ($uploadOk == 0) {
		echo "Sorry, your file was not uploaded.";
	// if everything is ok, try to upload file
	} else {
		if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
			echo "The file ". basename( $_POST['file_name']). " has been uploaded.";
		} else {
			//echo "Sorry, there was an error uploading your file.";
		}
	}
     
}

// Add css admin side pr plugin 
add_action('admin_head', 'pr_custom_fonts');

function pr_custom_fonts() {
  echo '<style>
    .toplevel_page_pdf-replace .wp-menu-image img{
      width:25px;
	  padding: 5px 0 0 !important;
    } 
	.pdf_replace input[type="text"]{
		width: 80%;
	}
  </style>';
}

// Active plgin create pdf-replace dir 
function prplugin_activate() {
	$upload_dir   = wp_upload_dir();
	if (!file_exists($upload_dir['basedir'].'/pdf-replace/')) {
		mkdir($upload_dir['basedir'].'/pdf-replace/', 0777, true);
	}
}
register_activation_hook( __FILE__, 'prplugin_activate' );



/**
 * Enqueue a script in the WordPress admin, excluding edit.php.
 *
 * @param int $hook Hook suffix for the current admin page.
 */
function prwpdocs_selectively_enqueue_admin_script( $hook ) {
    //wp_enqueue_script( 'pr_custom_script', plugin_dir_url( __FILE__ ) . 'js/custom.js', array(), '1.0' );
}
add_action( 'admin_enqueue_scripts', 'prwpdocs_selectively_enqueue_admin_script' );



add_action('admin_menu', 'books_register_ref_page');
/**
 * Adds a submenu page under a custom post type parent.
 */
function books_register_ref_page() {
    add_submenu_page(
        'edit.php?post_type=page',
        __( 'Books Shortcode Reference', 'textdomain' ),
        __( 'Shortcode Reference', 'textdomain' ),
        'manage_options',
        'books-shortcode-ref',
        'books_ref_page_callback'
    );
}
 
/**
 * Display callback for the submenu page.
 */
function books_ref_page_callback() { 
    ?>
    <div class="wrap">
        <h1><?php _e( 'Books Shortcode Reference', 'textdomain' ); ?></h1>
        <p><?php _e( 'Helpful stuff here', 'textdomain' ); ?></p>
    </div>
    <?php
}?>